import { Router } from "express";
import { Jimp } from "jimp";
import { createRequire } from "module";
import { db, topups, topupRequests, users, bankConfigs } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const require = createRequire(import.meta.url);
const jsQR = require("jsqr");

const router = Router();
const SLIP_WINDOW_MINUTES = 10;

/* ════════════════════════════════════════════════════════════
   MULTI-PASS QR IMAGE READER
════════════════════════════════════════════════════════════ */
async function readQrFromSlip(buffer: Buffer): Promise<string | null> {
  const decode = (img: InstanceType<typeof Jimp>): string | null => {
    const rgba = new Uint8ClampedArray(
      (img.bitmap.data as Buffer).buffer,
      (img.bitmap.data as Buffer).byteOffset,
      (img.bitmap.data as Buffer).byteLength,
    );
    return jsQR(rgba, img.bitmap.width, img.bitmap.height)?.data ?? null;
  };

  const img = await Jimp.read(buffer);
  const W = img.bitmap.width;
  const H = img.bitmap.height;

  return (
    decode(img) ??
    decode(img.clone().resize({ w: W * 2, h: H * 2 })) ??
    decode(img.clone().greyscale().contrast(0.6)) ??
    decode(img.clone().resize({ w: W * 3, h: H * 3 }).greyscale().contrast(0.4)) ??
    decode(
      img.clone()
        .crop({ x: Math.floor(W * 0.2), y: Math.floor(H * 0.2), w: Math.floor(W * 0.6), h: Math.floor(H * 0.6) })
        .resize({ w: Math.floor(W * 1.2), h: Math.floor(H * 1.2) }),
    ) ??
    decode(
      img.clone()
        .crop({ x: 0, y: Math.floor(H * 0.6), w: W, h: Math.floor(H * 0.4) })
        .resize({ w: W * 2, h: Math.floor(H * 0.8) }).greyscale(),
    )
  );
}

/* ════════════════════════════════════════════════════════════
   STANDARDS-COMPLIANT EMVCo TLV PARSER
   - Walks top-level TLVs from the first valid EMV header
   - Recursively descends into nested template tags
   - Returns BOTH a flat top-level map and a flat "all-tags" map
     (path-prefixed for nested fields, e.g. "29.00", "29.01")
════════════════════════════════════════════════════════════ */
type TlvNode = { tag: string; len: number; value: string; children?: TlvNode[] };

/** Tags whose value is itself a TLV stream (per EMVCo MPM spec + Thai banks). */
const TEMPLATE_TAGS = new Set<string>([
  // Merchant Account Information templates (per EMV: 02-51)
  ...Array.from({ length: 50 }, (_, i) => String(i + 2).padStart(2, "0")),
  "62", // Additional Data Field Template
  "64", // Merchant Information — Language Template
  // Unreserved templates 80-99
  ...Array.from({ length: 20 }, (_, i) => String(i + 80)),
]);

function parseTlvStream(raw: string, allowTemplates = true): TlvNode[] {
  const out: TlvNode[] = [];
  let i = 0;
  while (i + 4 <= raw.length) {
    const tag = raw.slice(i, i + 2);
    const lenStr = raw.slice(i + 2, i + 4);
    if (!/^\d{2}$/.test(tag) || !/^\d{2}$/.test(lenStr)) break;
    const len = parseInt(lenStr, 10);
    if (i + 4 + len > raw.length) break;
    const value = raw.slice(i + 4, i + 4 + len);
    const node: TlvNode = { tag, len, value };
    if (allowTemplates && TEMPLATE_TAGS.has(tag) && /^\d{4}/.test(value)) {
      // Probe: if the value parses as a clean TLV stream, treat as template
      const probe = parseTlvStream(value, true);
      const consumed = probe.reduce((s, n) => s + 4 + n.len, 0);
      if (probe.length > 0 && consumed === value.length) node.children = probe;
    }
    out.push(node);
    i += 4 + len;
  }
  return out;
}

interface FullParse {
  top: Record<string, string>;        // top-level tag -> value
  flat: Record<string, string>;       // dotted path (e.g. "29.01") -> value
  tree: TlvNode[];                    // full tree
}

function parseEmv(raw: string): FullParse {
  const start = raw.indexOf("000201");
  const stream = start >= 0 ? raw.slice(start) : raw;
  const tree = parseTlvStream(stream, true);
  const top: Record<string, string> = {};
  const flat: Record<string, string> = {};
  const walk = (nodes: TlvNode[], prefix: string) => {
    for (const n of nodes) {
      const key = prefix ? `${prefix}.${n.tag}` : n.tag;
      if (!prefix) top[n.tag] = n.value;
      flat[key] = n.value;
      if (n.children) walk(n.children, key);
    }
  };
  walk(tree, "");
  return { top, flat, tree };
}

/* ════════════════════════════════════════════════════════════
   AMOUNT EXTRACTOR

   Priority:
   1. EMV top-level tag 54 (PromptPay / dynamic QR)
   2. EMV nested tag 54 (rare but seen on some bank-issued QRs)
   3. Thai slip-QR formats (KTB / SCB / BBL / KBank / KMA after-transfer slip)
      - Often non-EMV, TLV starts at offset 0 with a 4-digit header
      - Amount typically encoded at known tag positions
   4. THB / ฿ / บาท / amount=... markers
   5. Decimal scan (avoiding year/date fragments)
════════════════════════════════════════════════════════════ */
function validAmount(v: string | undefined | null): number | null {
  if (!v) return null;
  const s = v.trim().replace(/,/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return null;
  const n = parseFloat(s);
  if (!isFinite(n) || n <= 0 || n >= 10_000_000) return null;
  return +n.toFixed(2);
}

function extractAmount(raw: string, full: FullParse): { amount: number | null; source: string } {
  // 1. EMV top-level 54
  const a1 = validAmount(full.top["54"]);
  if (a1) return { amount: a1, source: "emv.top.54" };

  // 2. EMV nested 54 (search flat map)
  for (const [k, v] of Object.entries(full.flat)) {
    if (k.endsWith(".54") || k === "54") {
      const a = validAmount(v);
      if (a) return { amount: a, source: `emv.${k}` };
    }
  }

  // 3. Thai bank slip QR non-EMV formats
  //    Try parsing the raw payload as a TLV stream WITHOUT requiring "000201" header.
  //    Banks' after-transfer slip QRs use TLV with their own tag map; some include amount.
  if (!raw.startsWith("000201")) {
    const altTree = parseTlvStream(raw, true);
    const altFlat: Record<string, string> = {};
    const walk = (nodes: TlvNode[], pre: string) => {
      for (const n of nodes) {
        const k = pre ? `${pre}.${n.tag}` : n.tag;
        altFlat[k] = n.value;
        if (n.children) walk(n.children, k);
      }
    };
    walk(altTree, "");
    // Tags that Thai bank slip QRs commonly use for amount
    for (const candidateTag of ["08", "09", "54", "07", "06"]) {
      for (const [k, v] of Object.entries(altFlat)) {
        if (k === candidateTag || k.endsWith("." + candidateTag)) {
          const a = validAmount(v);
          if (a) return { amount: a, source: `slipqr.${k}` };
          // Some banks encode amount in satang (integer cents)
          if (/^\d{3,10}$/.test(v.trim())) {
            const satang = parseInt(v.trim(), 10);
            const baht = satang / 100;
            if (baht > 0 && baht < 10_000_000 && satang % 1 === 0) {
              // Heuristic: only accept if value length suggests satang encoding
              if (v.trim().length >= 3) {
                return { amount: +baht.toFixed(2), source: `slipqr.satang.${k}` };
              }
            }
          }
        }
      }
    }
  }

  // 4. Currency / keyword markers
  for (const p of [
    /(?:THB|฿)\s*(\d[\d,]*(?:\.\d{1,2})?)/i,
    /(\d[\d,]*(?:\.\d{1,2})?)\s*(?:THB|฿|บาท)/i,
    /(?:amount|amt|จำนวน|ยอด)\s*[=:]\s*(\d[\d,]*(?:\.\d{1,2})?)/i,
  ]) {
    const m = raw.match(p);
    if (m) {
      const a = validAmount(m[1]);
      if (a) return { amount: a, source: "marker" };
    }
  }

  // 5. JSON / URL fallbacks
  const json = raw.match(/"(?:amount|total|value|sum)"\s*:\s*"?(\d[\d.]*)"?/i);
  if (json) {
    const a = validAmount(json[1]);
    if (a) return { amount: a, source: "json" };
  }
  const url = raw.match(/[?&](?:amount|amt|sum|value)=(\d[\d.]*)/i);
  if (url) {
    const a = validAmount(url[1]);
    if (a) return { amount: a, source: "url" };
  }

  // 6. Decimal scan, last resort (skip year-like 20xx and timestamps)
  for (const m of raw.matchAll(/(\d{1,7})\.(\d{1,2})(?!\d)/g)) {
    const a = validAmount(m[0]);
    if (a && !(a >= 2020 && a <= 2099 && m[2].length === 2 && !m[0].includes(","))) {
      // skip obvious year matches like 2024.01
      if (a >= 2020 && a <= 2099) continue;
      return { amount: a, source: "decimal-scan" };
    }
  }

  return { amount: null, source: "none" };
}

/* ════════════════════════════════════════════════════════════
   PARSER: receiver / bank / ref / timestamp
════════════════════════════════════════════════════════════ */
interface ParsedSlip {
  transRef: string | null;
  amount: number | null;
  amountSource: string;
  receiverAccount: string | null;
  receiverName: string | null;
  senderAccount: string | null;
  senderName: string | null;
  bankCode: string | null;
  bankName: string | null;
  slipTimestamp: Date | null;
  rawQr: string;
  emvTop: Record<string, string>;
  emvFlat: Record<string, string>;
}

const BANK_CODE_MAP: Record<string, string> = {
  "002": "BBL  (Bangkok Bank)",
  "004": "KBANK (Kasikornbank / K PLUS)",
  "006": "KTB  (Krungthai / Krungthai NEXT / KMA)",
  "011": "TTB  (TMBThanachart)",
  "014": "SCB  (Siam Commercial / SCB EASY)",
  "022": "CIMBT",
  "025": "BAY  (Krungsri / KMA)",
  "069": "KKP",
  "067": "TISCO",
  "024": "UOB",
  "030": "GSB",
  "033": "GHB",
  "034": "BAAC",
  "073": "LH Bank",
};

function normalise(s: string) { return s.replace(/[-\s.]/g, "").toLowerCase(); }

function parseQrData(raw: string): ParsedSlip {
  const full = parseEmv(raw);
  const { amount, source: amountSource } = extractAmount(raw, full);

  // Receiver name — EMV tag 59 (Merchant Name)
  let receiverName: string | null = full.top["59"]?.trim() || null;

  // Receiver account / PromptPay ID — search EMV merchant account templates (29, 30) first
  let receiverAccount: string | null = null;
  for (const [k, v] of Object.entries(full.flat)) {
    if (!/^(29|30|31)\./.test(k)) continue;
    // PromptPay sub-tags: 01=mobile (00668...), 02=natID (13 digits), 03=eWallet
    if (/^00\d{10,}$/.test(v) || /^\d{13}$/.test(v) || /^0[689]\d{8}$/.test(v)) {
      receiverAccount = v.startsWith("0066") ? "0" + v.slice(4) : v;
      break;
    }
  }
  if (!receiverAccount) {
    const mob = raw.match(/0[689]\d{8}/);
    if (mob) receiverAccount = mob[0];
  }
  if (!receiverAccount) {
    const natId = raw.match(/(?<![0-9])\d{13}(?![0-9])/);
    if (natId) receiverAccount = natId[0];
  }
  if (!receiverAccount) {
    const acct = raw.match(/(?<![0-9])\d{10,12}(?![0-9])/);
    if (acct) receiverAccount = acct[0];
  }

  // Bank code — look for BOT 3-digit bank ID in EMV merchant info first
  let bankCode: string | null = null;
  let bankName: string | null = null;
  for (const [k, v] of Object.entries(full.flat)) {
    if (/^(29|30|31)\./.test(k) && /^\d{3,4}$/.test(v) && BANK_CODE_MAP[v.padStart(3, "0").slice(-3)]) {
      const code = v.padStart(3, "0").slice(-3);
      bankCode = code;
      bankName = BANK_CODE_MAP[code];
      break;
    }
  }
  if (!bankCode) {
    const bm = raw.match(/\b(KBANK|KBank|SCB|KTB|BBL|UOB|TTB|TISCO|CIMBT|LHBANK|GSB|BAAC|BAY|KKP|GHB)\b/i);
    if (bm) { bankCode = bm[1].toUpperCase(); bankName = bm[1].toUpperCase(); }
  }

  // Transaction reference
  let transRef: string | null = null;
  // EMV Additional Data Field Template (62) -> sub-tag 05 = Reference Label
  if (full.flat["62.05"]) transRef = full.flat["62.05"].trim();
  if (!transRef) {
    for (const m of raw.matchAll(/[A-Z]{1,6}[0-9]{8,20}|[0-9]{8,20}[A-Z]{1,6}/g)) {
      if (m[0].length >= 10 && m[0].length <= 26) { transRef = m[0]; break; }
    }
  }
  if (!transRef) {
    const m = raw.match(/(?<![0-9])(?!20\d{6})\d{14,20}(?![0-9])/);
    if (m) transRef = m[0];
  }
  if (!transRef) {
    const m = raw.match(/(?<![0-9])\d{10,13}(?![0-9])/);
    if (m) transRef = m[0];
  }
  if (!transRef) {
    let h = 5381;
    for (let j = 0; j < raw.length; j++) h = ((h << 5) + h + raw.charCodeAt(j)) & 0xffffffff;
    transRef = "QRH" + Math.abs(h).toString(16).toUpperCase().padStart(8, "0");
  }

  // Sender (rarely encoded in slip QR; left for future expansion)
  const senderAccount: string | null = null;
  const senderName: string | null = null;

  // Timestamp
  let slipTimestamp: Date | null = null;
  const ts14 = raw.match(/(20\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])([0-5]\d)([0-5]\d)/);
  if (ts14) {
    const d = new Date(`${ts14[1]}-${ts14[2]}-${ts14[3]}T${ts14[4]}:${ts14[5]}:${ts14[6]}+07:00`);
    if (!isNaN(d.getTime())) slipTimestamp = d;
  }
  if (!slipTimestamp) {
    const iso = raw.match(/(20\d{2}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d)/);
    if (iso) {
      const d = new Date(iso[1] + ":00+07:00");
      if (!isNaN(d.getTime())) slipTimestamp = d;
    }
  }

  return {
    transRef, amount, amountSource,
    receiverAccount, receiverName,
    senderAccount, senderName,
    bankCode, bankName,
    slipTimestamp, rawQr: raw,
    emvTop: full.top, emvFlat: full.flat,
  };
}

/* ════════════════════════════════════════════════════════════
   POST /topup-requests/slip-debug   (admin diagnostic)
════════════════════════════════════════════════════════════ */
router.post("/topup-requests/slip-debug", async (req, res) => {
  const userId = req.session?.userId;
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }

  const { slip_base64, raw_qr } = req.body as { slip_base64?: string; raw_qr?: string };

  let qrRaw: string | null = raw_qr ?? null;
  if (!qrRaw) {
    if (!slip_base64) { res.status(400).json({ error: "No image or raw_qr" }); return; }
    let buf: Buffer;
    try { buf = Buffer.from(slip_base64.replace(/^data:image\/\w+;base64,/, ""), "base64"); }
    catch { res.status(400).json({ error: "Bad image" }); return; }
    try { qrRaw = await readQrFromSlip(buf); } catch { /* ignore */ }
  }

  if (!qrRaw) { res.json({ found: false, error: "ไม่พบ QR Code ในรูปภาพ" }); return; }

  const parsed = parseQrData(qrRaw);

  res.json({
    found: true,
    raw_qr: qrRaw,
    raw_length: qrRaw.length,
    emv_top_tags: parsed.emvTop,
    emv_all_tags: parsed.emvFlat,
    parsed: {
      amount: parsed.amount,
      amount_source: parsed.amountSource,
      transRef: parsed.transRef,
      receiverAccount: parsed.receiverAccount,
      receiverName: parsed.receiverName,
      senderAccount: parsed.senderAccount,
      senderName: parsed.senderName,
      bankCode: parsed.bankCode,
      bankName: parsed.bankName,
      slipTimestamp: parsed.slipTimestamp,
    },
    error_reason: parsed.amount ? null : "QR detected but amount not found in payload",
  });
});

/* ════════════════════════════════════════════════════════════
   POST /topup-requests/slip-verify   (main endpoint)
════════════════════════════════════════════════════════════ */
router.post("/topup-requests/slip-verify", async (req, res) => {
  const userId = req.session?.userId;
  if (!userId) { res.status(401).json({ error: "กรุณาเข้าสู่ระบบก่อน" }); return; }

  const { slip_base64 } = req.body as { slip_base64?: string };
  if (!slip_base64) { res.status(400).json({ error: "กรุณาแนบสลิปการโอนเงิน" }); return; }

  let imageBuffer: Buffer;
  try {
    imageBuffer = Buffer.from(slip_base64.replace(/^data:image\/\w+;base64,/, ""), "base64");
  } catch {
    res.status(400).json({ error: "รูปภาพไม่ถูกต้อง กรุณาลองใหม่" }); return;
  }

  let qrRaw: string | null = null;
  try { qrRaw = await readQrFromSlip(imageBuffer); }
  catch (err) {
    req.log.error(err, "QR image error");
    res.status(400).json({ error: "อ่านรูปภาพไม่ได้ กรุณาลองใหม่" }); return;
  }

  if (!qrRaw) {
    res.status(400).json({
      error: "ไม่พบ QR Code — ถ่ายให้เห็น QR ชัดๆ ครบทั้งสลิป แสงพอ ไม่เบลอ",
    });
    return;
  }

  req.log.info({ qrLen: qrRaw.length, raw: qrRaw.slice(0, 400) }, "QR_RAW");

  const parsed = parseQrData(qrRaw);
  req.log.info(
    { amount: parsed.amount, amountSource: parsed.amountSource, transRef: parsed.transRef, rcv: parsed.receiverAccount },
    "QR_PARSED",
  );

  if (!parsed.amount || parsed.amount <= 0) {
    req.log.warn({ fullRaw: qrRaw, emvTop: parsed.emvTop }, "AMOUNT_NOT_FOUND");
    res.status(400).json({
      error:
        "อ่าน QR ได้ แต่ไม่พบยอดเงินในข้อมูล\n" +
        "แอดมินสามารถดูข้อมูล QR ดิบในหน้า 'ตรวจสอบสลิป (Debug)' เพื่อระบุรูปแบบธนาคาร",
      debug_ref: parsed.transRef,
    });
    return;
  }

  const finalAmount = parsed.amount;
  const transRef = parsed.transRef!;

  const activeBanks = await db
    .select({ account_number: bankConfigs.account_number, account_name: bankConfigs.account_name, bank_name: bankConfigs.bank_name })
    .from(bankConfigs).where(eq(bankConfigs.is_active, true));

  if (activeBanks.length === 0) {
    res.status(503).json({ error: "ยังไม่ได้ตั้งค่าบัญชีธนาคาร กรุณาติดต่อแอดมิน" }); return;
  }

  const dup = await db.select({ id: topups.id }).from(topups).where(eq(topups.trans_ref, transRef)).limit(1);
  if (dup.length > 0) {
    res.status(400).json({ error: "สลิปนี้ถูกใช้งานไปแล้ว" }); return;
  }

  if (parsed.slipTimestamp) {
    const ageMins = (Date.now() - parsed.slipTimestamp.getTime()) / 60000;
    if (ageMins > SLIP_WINDOW_MINUTES) {
      res.status(400).json({ error: `สลิปหมดอายุ — อายุ ${Math.round(ageMins)} นาที (ต้องส่งภายใน ${SLIP_WINDOW_MINUTES} นาที)` });
      return;
    }
    if (ageMins < -5) { res.status(400).json({ error: "เวลาในสลิปผิดปกติ" }); return; }
  }

  let receiverMatchLog = "no_id";
  let hardReject = false;
  if (parsed.receiverAccount) {
    const nq = normalise(parsed.receiverAccount);
    const matched = activeBanks.some(b => {
      const na = normalise(b.account_number);
      return na === nq || na.includes(nq) || nq.includes(na) || na.slice(-8) === nq.slice(-8);
    });
    const isPromptPay = /^0[689]\d{8}$/.test(parsed.receiverAccount) || /^\d{13}$/.test(parsed.receiverAccount);
    receiverMatchLog = matched ? "matched" : `unmatched:${parsed.receiverAccount}`;
    hardReject = !matched && !isPromptPay;
    if (!matched) req.log.warn({ rcv: parsed.receiverAccount }, "Receiver mismatch");
  }
  if (hardReject) {
    res.status(400).json({ error: "บัญชีผู้รับในสลิปไม่ตรงกับบัญชีของร้าน กรุณาโอนมายังบัญชีที่ระบุ" });
    return;
  }

  if (parsed.bankCode) {
    const matched = activeBanks.some(b => normalise(b.bank_name).includes(normalise(parsed.bankCode!)));
    if (!matched) req.log.warn({ bank: parsed.bankCode }, "Bank mismatch warn");
  }

  try {
    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user) { res.status(404).json({ error: "ไม่พบบัญชีผู้ใช้" }); return; }

    const newBalance = +(((user.balance ?? 0) + finalAmount).toFixed(2));

    await db.transaction(async (tx) => {
      await tx.update(users).set({ balance: newBalance, total_topup: sql`${users.total_topup} + ${finalAmount}` }).where(eq(users.id, userId));
      await tx.insert(topups).values({ user_id: userId, amount: finalAmount, method: "Slip (QR-Direct)", status: "success", trans_ref: transRef });
      await tx.insert(topupRequests).values({
        user_id: userId, username: user.username, amount: finalAmount, method: "slip",
        slip_url: slip_base64.slice(0, 2000), status: "approved",
        note: `ref:${transRef}|amt:${finalAmount}|rcv:${receiverMatchLog}`,
      });
    });

    req.log.info({ userId, finalAmount, transRef, newBalance }, "Slip credited");
    res.json({ ok: true, mode: "auto", amount: finalAmount, new_balance: newBalance, ref: transRef });
  } catch (err) {
    req.log.error(err, "DB error");
    res.status(500).json({ error: "เกิดข้อผิดพลาด กรุณาลองใหม่" });
  }
});

/* ── admin: list all topup requests ── */
router.get("/topup-requests", async (req, res) => {
  try {
    res.json(await db.select().from(topupRequests).orderBy(desc(topupRequests.created_at)));
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

/* ── admin: approve ── */
router.post("/topup-requests/:id/approve", async (req, res) => {
  try {
    const { amount } = req.body as { amount?: number };
    if (!amount || amount <= 0) { res.status(400).json({ error: "Invalid amount" }); return; }
    const [r] = await db.select().from(topupRequests).where(eq(topupRequests.id, req.params.id));
    if (!r) { res.status(404).json({ error: "Not found" }); return; }
    await db.transaction(async (tx) => {
      await tx.update(topupRequests).set({ status: "approved", amount }).where(eq(topupRequests.id, req.params.id));
      await tx.update(users).set({ balance: sql`${users.balance} + ${amount}`, total_topup: sql`${users.total_topup} + ${amount}` }).where(eq(users.id, r.user_id));
      await tx.insert(topups).values({ user_id: r.user_id, amount, method: r.method === "slip" ? "Slip (แอดมินอนุมัติ)" : "TrueMoney/Angpao", status: "success" });
    });
    res.json({ ok: true });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

/* ── admin: reject ── */
router.post("/topup-requests/:id/reject", async (req, res) => {
  try {
    await db.update(topupRequests).set({ status: "rejected" }).where(eq(topupRequests.id, req.params.id));
    res.json({ ok: true });
  } catch (err) { req.log.error(err); res.status(500).json({ error: "Failed" }); }
});

export default router;
