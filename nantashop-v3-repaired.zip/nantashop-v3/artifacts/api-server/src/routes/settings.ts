import { Router } from "express";
import { db, websiteSettings } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function getOrCreate() {
  const rows = await db.select().from(websiteSettings).limit(1);
  if (rows.length > 0) return rows[0];
  const inserted = await db.insert(websiteSettings).values({ site_name: "NantaShop" }).returning();
  return inserted[0];
}

router.get("/settings", async (req, res) => {
  try {
    const row = await getOrCreate();
    res.json(row);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to fetch settings" });
  }
});

router.patch("/settings", async (req, res) => {
  try {
    const row = await getOrCreate();
    const updated = await db
      .update(websiteSettings)
      .set(req.body)
      .where(eq(websiteSettings.id, row.id))
      .returning();
    res.json(updated[0]);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to update settings" });
  }
});

export default router;
