import { useState, useRef } from "react";
import { api } from "@/lib/api";

/* ════════════════════════════════════════════════════════════
   Admin → Slip Debug
   Standalone diagnostic tool. POSTs to /api/topup-requests/slip-debug
   and renders the full parser result.
════════════════════════════════════════════════════════════ */

interface DebugResponse {
  found: boolean;
  raw_qr?: string;
  raw_length?: number;
  emv_top_tags?: Record<string, string>;
  emv_all_tags?: Record<string, string>;
  parsed?: {
    amount: number | null;
    amount_source: string;
    transRef: string | null;
    receiverAccount: string | null;
    receiverName: string | null;
    senderAccount: string | null;
    senderName: string | null;
    bankCode: string | null;
    bankName: string | null;
    slipTimestamp: string | null;
  };
  error_reason?: string | null;
  error?: string;
}

export default function AdminSlipDebug() {
  const [loading, setLoading] = useState(false);
  const [resp, setResp] = useState<DebugResponse | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [rawInput, setRawInput] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function runWithImage(file: File) {
    setErr(null); setResp(null); setLoading(true);
    try {
      const b64: string = await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result as string);
        r.onerror = reject;
        r.readAsDataURL(file);
      });
      const data = await api.post("/topup-requests/slip-debug", { slip_base64: b64 });
      setResp(data);
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally { setLoading(false); }
  }

  async function runWithRaw() {
    if (!rawInput.trim()) return;
    setErr(null); setResp(null); setLoading(true);
    try {
      const data = await api.post("/topup-requests/slip-debug", { raw_qr: rawInput.trim() });
      setResp(data);
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed");
    } finally { setLoading(false); }
  }

  const p = resp?.parsed;

  return (
    <div className="min-h-screen bg-[#0e1015] text-white p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Slip Debug Console</h1>
            <p className="text-sm text-gray-400">
              วิเคราะห์ QR ของสลิปธนาคารทุกธนาคาร — EMVCo / PromptPay / Bank Slip-QR
            </p>
          </div>
          <a href="/admin" className="text-sm px-3 py-2 rounded-lg bg-[#1a1d27] hover:bg-[#252836]">
            ← กลับหน้า Admin
          </a>
        </header>

        {/* INPUT */}
        <section className="grid md:grid-cols-2 gap-4">
          <div className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
            <h2 className="font-semibold mb-3">1. อัปโหลดภาพสลิป</h2>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              onChange={e => e.target.files?.[0] && runWithImage(e.target.files[0])}
              className="block w-full text-sm file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-blue-600 file:text-white hover:file:bg-blue-700"
            />
            <p className="text-xs text-gray-500 mt-2">
              ระบบจะถอด QR แบบ multi-pass (resize / greyscale / crop) แล้ววิเคราะห์โครงสร้าง TLV
            </p>
          </div>
          <div className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
            <h2 className="font-semibold mb-3">2. หรือวาง Raw QR Payload</h2>
            <textarea
              value={rawInput}
              onChange={e => setRawInput(e.target.value)}
              rows={4}
              placeholder="00020101021229370016A00000067701..."
              className="w-full text-xs font-mono bg-[#0e1015] border border-[#252836] rounded-lg p-2"
            />
            <button
              onClick={runWithRaw}
              disabled={loading || !rawInput.trim()}
              className="mt-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-sm"
            >
              วิเคราะห์
            </button>
          </div>
        </section>

        {loading && (
          <div className="rounded-xl bg-[#161922] border border-[#252836] p-6 text-center text-gray-400">
            กำลังประมวลผล…
          </div>
        )}

        {err && (
          <div className="rounded-xl bg-red-500/10 border border-red-500/40 p-4 text-red-300">
            {err}
          </div>
        )}

        {resp && !resp.found && (
          <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/40 p-4 text-yellow-300">
            ไม่พบ QR Code ในรูปภาพนี้ — โปรดตรวจสอบความคมชัด / มุมถ่าย
          </div>
        )}

        {resp?.found && p && (
          <>
            {/* PARSED SUMMARY */}
            <section className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
              <h2 className="font-semibold mb-4">📋 Parsed Result</h2>
              <div className="grid md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                <Row label="Amount" value={p.amount != null ? `฿ ${p.amount.toFixed(2)}` : "— (not found)"} highlight={p.amount == null ? "warn" : "ok"} />
                <Row label="Amount Source" value={p.amount_source} />
                <Row label="Reference No." value={p.transRef} />
                <Row label="Bank" value={p.bankName || p.bankCode} />
                <Row label="Receiver Account" value={p.receiverAccount} />
                <Row label="Receiver Name" value={p.receiverName} />
                <Row label="Sender Account" value={p.senderAccount} />
                <Row label="Sender Name" value={p.senderName} />
                <Row label="Transaction Date" value={p.slipTimestamp ? new Date(p.slipTimestamp).toLocaleString("th-TH") : null} />
                <Row label="Raw Length" value={String(resp.raw_length ?? "-")} />
              </div>
              {resp.error_reason && (
                <div className="mt-4 px-3 py-2 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-yellow-300 text-sm">
                  ⚠ {resp.error_reason}
                </div>
              )}
            </section>

            {/* EMV TAGS */}
            <section className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
              <h2 className="font-semibold mb-3">🏷 Parsed EMV Tags</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <TagTable title="Top-level" tags={resp.emv_top_tags || {}} />
                <TagTable title="All (incl. nested templates)" tags={resp.emv_all_tags || {}} />
              </div>
            </section>

            {/* RAW */}
            <section className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
              <h2 className="font-semibold mb-3">📦 Raw QR Payload</h2>
              <pre className="bg-[#0e1015] border border-[#252836] rounded-lg p-3 text-xs font-mono overflow-x-auto whitespace-pre-wrap break-all">
{resp.raw_qr}
              </pre>
            </section>

            {/* FULL JSON */}
            <section className="rounded-2xl bg-[#161922] border border-[#252836] p-5">
              <h2 className="font-semibold mb-3">🧾 Complete Parser Result (JSON)</h2>
              <pre className="bg-[#0e1015] border border-[#252836] rounded-lg p-3 text-xs font-mono overflow-x-auto">
{JSON.stringify(resp, null, 2)}
              </pre>
            </section>
          </>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string | number | null | undefined; highlight?: "ok" | "warn" }) {
  const color = highlight === "warn" ? "text-yellow-300" : highlight === "ok" ? "text-emerald-300" : "text-white";
  return (
    <div className="flex justify-between border-b border-[#252836]/60 pb-1.5">
      <span className="text-gray-400">{label}</span>
      <span className={`font-mono ${color}`}>{value ?? "—"}</span>
    </div>
  );
}

function TagTable({ title, tags }: { title: string; tags: Record<string, string> }) {
  const entries = Object.entries(tags);
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-gray-500 mb-2">{title}</div>
      <div className="rounded-lg border border-[#252836] overflow-hidden">
        <table className="w-full text-xs font-mono">
          <tbody>
            {entries.length === 0 && (
              <tr><td className="p-2 text-gray-500">— empty —</td></tr>
            )}
            {entries.map(([k, v]) => (
              <tr key={k} className="border-t border-[#252836]">
                <td className="p-1.5 px-2 text-blue-300 align-top w-16">{k}</td>
                <td className="p-1.5 px-2 break-all text-gray-200">{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
