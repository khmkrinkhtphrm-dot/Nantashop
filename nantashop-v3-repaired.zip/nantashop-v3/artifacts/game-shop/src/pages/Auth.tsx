import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { Gamepad2, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useApp } from "@/context/AppContext";
import { api } from "@/lib/api";
import { UserProfile } from "@/types";

const loginSchema = z.object({
  username: z.string().min(1, "กรุณาใส่ Username"),
  password: z.string().min(6, "Password ต้องมีอย่างน้อย 6 ตัวอักษร"),
});
const registerSchema = z.object({
  username: z.string().min(3, "Username ต้องมีอย่างน้อย 3 ตัวอักษร"),
  password: z.string().min(6, "Password ต้องมีอย่างน้อย 6 ตัวอักษร"),
});

type LoginData = z.infer<typeof loginSchema>;
type RegisterData = z.infer<typeof registerSchema>;

export default function Auth() {
  const [, setLocation] = useLocation();
  const { setCurrentUser } = useApp();
  const { toast } = useToast();
  const [isRegister, setIsRegister] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const loginForm = useForm<LoginData>({ resolver: zodResolver(loginSchema), defaultValues: { username: "", password: "" } });
  const registerForm = useForm<RegisterData>({ resolver: zodResolver(registerSchema), defaultValues: { username: "", password: "" } });

  async function handleLogin(data: LoginData) {
    setLoading(true);
    try {
      const user = await api.post("/auth/login", { username: data.username, password: data.password });
      setCurrentUser(user as UserProfile);
      toast({ title: `ยินดีต้อนรับกลับมา, ${(user as UserProfile).username}!` });
      setLocation("/");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "เข้าสู่ระบบไม่สำเร็จ";
      toast({ title: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(data: RegisterData) {
    setLoading(true);
    try {
      const user = await api.post("/auth/register", { username: data.username, password: data.password });
      setCurrentUser(user as UserProfile);
      toast({ title: `สมัครสมาชิกสำเร็จ! ยินดีต้อนรับ, ${(user as UserProfile).username}!` });
      setLocation("/");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "สมัครสมาชิกไม่สำเร็จ";
      toast({ title: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-background">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-primary/40">
            <Gamepad2 className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-extrabold text-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            {isRegister ? "สมัครสมาชิก" : "ยินดีต้อนรับ"}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isRegister ? "สร้างบัญชีใหม่เพื่อเข้าใช้งาน" : "เข้าสู่ระบบเพื่อดำเนินการต่อ"}
          </p>
        </div>

        <div className="rounded-2xl border border-border bg-card p-8 shadow-2xl shadow-black/30">
          <div className="flex rounded-xl bg-secondary p-1 mb-6">
            {[["เข้าสู่ระบบ", "login"], ["สมัครสมาชิก", "register"]].map(([label, key], i) => (
              <button
                key={key}
                onClick={() => setIsRegister(i === 1)}
                className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
                  (i === 0 && !isRegister) || (i === 1 && isRegister)
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {!isRegister ? (
              <motion.form key="login" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Username</label>
                  <Input {...loginForm.register("username")} placeholder="ใส่ Username" autoComplete="username" />
                  {loginForm.formState.errors.username && <p className="text-destructive text-xs mt-1">{loginForm.formState.errors.username.message}</p>}
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Password</label>
                  <div className="relative">
                    <Input {...loginForm.register("password")} type={showPass ? "text" : "password"} placeholder="••••••••" className="pr-10" autoComplete="current-password" />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {loginForm.formState.errors.password && <p className="text-destructive text-xs mt-1">{loginForm.formState.errors.password.message}</p>}
                </div>
                <Button type="submit" className="w-full h-11 shadow-lg shadow-primary/20" disabled={loading}>
                  {loading ? <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "เข้าสู่ระบบ"}
                </Button>
              </motion.form>
            ) : (
              <motion.form key="register" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Username</label>
                  <Input {...registerForm.register("username")} placeholder="อย่างน้อย 3 ตัวอักษร" autoComplete="username" />
                  {registerForm.formState.errors.username && <p className="text-destructive text-xs mt-1">{registerForm.formState.errors.username.message}</p>}
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Password</label>
                  <div className="relative">
                    <Input {...registerForm.register("password")} type={showPass ? "text" : "password"} placeholder="อย่างน้อย 6 ตัวอักษร" className="pr-10" autoComplete="new-password" />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {registerForm.formState.errors.password && <p className="text-destructive text-xs mt-1">{registerForm.formState.errors.password.message}</p>}
                </div>
                <Button type="submit" className="w-full h-11 shadow-lg shadow-primary/20" disabled={loading}>
                  {loading ? <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "สมัครสมาชิก"}
                </Button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
