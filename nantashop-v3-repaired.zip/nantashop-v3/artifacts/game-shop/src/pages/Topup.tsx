import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Gift, Upload, Link2, CheckCircle, AlertCircle, ImageIcon, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useApp } from "@/context/AppContext";
import { api } from "@/lib/api";
import { useLocation } from "wouter";

type Method = "slip" | "angpao" | "redeem";

function ConfirmDialog({
  open, title, body, onConfirm, onCancel, loading,
}: {
  open: boolean; title: string; body?: string;
  onConfirm: () => void; onCancel: () => void; loading?: boolean;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      onClick={() => !loading && onCancel()}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
        className="bg-card border border-border rounded-2xl p-6 max-w-sm w-full shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-center mb-4">
          <div className="w-14 h-14 rounded-full bg-orange-500/15 border-2 border-orange-500/30 flex items-center justify-center">
            <AlertCircle className="w-7 h-7 text-orange-400" />
          </div>
        </div>
        <h3 className="text-center text-lg font-bold text-foreground mb-1">{title}</h3>
        {body && <p className="text-center text-sm text-muted-foreground mb-3">{body}</p>}
        <div className="flex gap-3 mt-5">
          <Button onClick={onConfirm} disabled={loading} className="flex-1 h-11 font-semibold">
            {loading
              ? <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              : "ยืนยัน"}
          </Button>
          <Button variant="destructive" onClick={onCancel} disabled={loading} className="flex-1 h-11 font-semibold">
            ยกเลิก
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

export default function Topup() {
  const { currentUser, updateBalance } = useApp();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [method, setMethod] = useState<Method>("slip");

  // ── Slip state ──────────────────────────────────────────
  const [slipPreview, setSlipPreview] = useState<string>("");
  const [slipSubmitting, setSlipSubmitting] = useState(false);
  const [slipConfirmOpen, setSlipConfirmOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // ── Angpao state ────────────────────────────────────────
  const [angpaoUrl, setAngpaoUrl] = useState("");
  const [angpaoSubmitting, setAngpaoSubmitting] = useState(false);
  const [angpaoConfirmOpen, setAngpaoConfirmOpen] = useState(false);

  // ── Redeem state ────────────────────────────────────────
  const [redeemCode, setRedeemCode] = useState("");
  const [redeemSubmitting, setRedeemSubmitting] = useState(false);
  const [redeemConfirmOpen, setRedeemConfirmOpen] = useState(false);

  // ── Bank / wallet config from admin ─────────────────────
  const [walletPhone, setWalletPhone] = useState("0812345678");
  const [bankList, setBankList] = useState<
    { bank_name: string; account_number: string; account_name: string }[]
  >([{ bank_name: "ธนาคารไทยพาณิชย์ (SCB)", account_number: "123-456-7890", account_name: "NantaShop Admin" }]);

  useEffect(() => {
    api
      .get("/wallet-configs")
      .then((d: { phone_number: string }[]) => { if (d?.[0]?.phone_number) setWalletPhone(d[0].phone_number); })
      .catch(() => {});
    api
      .get("/bank-configs")
      .then((d: typeof bankList) => { if (d?.length) setBankList(d); })
      .catch(() => {});
  }, []);

  if (!currentUser) {
    return (
      <div className="max-w-lg mx-auto px-4 py-24 text-center">
        <div className="p-6 rounded-2xl bg-card border border-border">
          <h2 className="text-xl font-bold text-foreground mb-3">กรุณาเข้าสู่ระบบ</h2>
          <p className="text-muted-foreground text-sm mb-6">เข้าสู่ระบบก่อนเติมเงิน</p>
          <Button onClick={() => setLocation("/auth")} className="w-full">เข้าสู่ระบบ / สมัครสมาชิก</Button>
        </div>
      </div>
    );
  }

  /* ── helpers ─────────────────────────────────────────── */
  function readFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target?.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function clearSlip() {
    setSlipPreview("");
    if (fileRef.current) fileRef.current.value = "";
  }

  async function handleSlipFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await readFile(file);
    setSlipPreview(url);
  }

  /* ── slip submit ─────────────────────────────────────── */
  function submitSlip() {
    if (!slipPreview) {
      toast({ title: "กรุณาแนบสลิปการโอนเงิน", variant: "destructive" });
      return;
    }
    setSlipConfirmOpen(true);
  }

  async function confirmSlip() {
    if (!currentUser) return;
    setSlipSubmitting(true);
    try {
      const data = await api.post("/topup-requests/slip-verify", {
        slip_base64: slipPreview,
      }) as {
        ok: boolean;
        amount?: number;
        new_balance?: number;
        ref?: string;
      };

      if (data.new_balance !== undefined) updateBalance(data.new_balance);
      toast({
        title: `✅ เติมเงินสำเร็จ! +฿${(data.amount ?? 0).toLocaleString()}`,
        description: data.ref ? `อ้างอิง: ${data.ref}` : "เงินเข้าวอเล็ทของคุณแล้ว",
      });
      clearSlip();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "ตรวจสอบสลิปไม่สำเร็จ กรุณาลองใหม่";
      toast({ title: "ตรวจสอบสลิปไม่สำเร็จ", description: msg, variant: "destructive" });
    }
    setSlipSubmitting(false);
    setSlipConfirmOpen(false);
  }

  /* ── angpao submit ───────────────────────────────────── */
  function submitAngpao() {
    if (!angpaoUrl || !angpaoUrl.includes("truemoney.com")) {
      toast({ title: "กรุณาใส่ลิ้งค์อั่งเปา TrueMoney ที่ถูกต้อง", variant: "destructive" });
      return;
    }
    setAngpaoConfirmOpen(true);
  }

  async function confirmAngpao() {
    if (!currentUser) return;
    setAngpaoSubmitting(true);
    try {
      const data = await api.post("/angpao/redeem", { url: angpaoUrl }) as {
        amount: number;
        new_balance: number;
      };
      updateBalance(data.new_balance);
      toast({
        title: `🧧 รับอั้งเปาสำเร็จ! +฿${data.amount.toLocaleString()}`,
        description: "เงินเข้าวอเล็ทของคุณทันที",
      });
      setAngpaoUrl("");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "รับอั้งเปาไม่สำเร็จ";
      toast({ title: msg, variant: "destructive" });
    }
    setAngpaoSubmitting(false);
    setAngpaoConfirmOpen(false);
  }

  /* ── redeem submit ───────────────────────────────────── */
  function submitRedeem() {
    if (!redeemCode.trim()) {
      toast({ title: "กรุณาใส่โค้ดเติมเงิน", variant: "destructive" });
      return;
    }
    setRedeemConfirmOpen(true);
  }

  async function confirmRedeem() {
    if (!currentUser) return;
    setRedeemSubmitting(true);
    try {
      const data = await api.post("/redeem-codes/use", {
        user_id: currentUser.id,
        code: redeemCode.trim().toUpperCase(),
      });
      if (data?.new_balance !== undefined) updateBalance(data.new_balance);
      toast({ title: `เติมเงินสำเร็จ! +฿${data?.amount?.toLocaleString() ?? ""}` });
      setRedeemCode("");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "โค้ดไม่ถูกต้อง";
      toast({ title: msg, variant: "destructive" });
    }
    setRedeemSubmitting(false);
    setRedeemConfirmOpen(false);
  }

  const tabs: { id: Method; label: string; icon: React.ReactNode }[] = [
    { id: "slip",   label: "Slip Check",        icon: <Upload className="w-4 h-4" /> },
    { id: "angpao", label: "TrueMoney Angpao",  icon: <Gift className="w-4 h-4" /> },
    { id: "redeem", label: "Redeem Code",        icon: <Link2 className="w-4 h-4" /> },
  ];

  return (
    <>
      <div className="max-w-lg mx-auto px-4 py-8 space-y-6">

        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1">เติมเงิน</h1>
          <p className="text-muted-foreground text-sm">
            ยอดเงินคงเหลือ:{" "}
            <span className="text-primary font-semibold">฿{currentUser.balance.toLocaleString()}</span>
          </p>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-3 gap-2">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setMethod(t.id)}
              className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border font-medium text-xs transition-all duration-200 ${
                method === t.id
                  ? "bg-primary/15 border-primary/60 text-primary shadow-sm shadow-primary/10"
                  : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-foreground/20"
              }`}
            >
              {t.icon}
              <span className="text-center leading-tight">{t.label}</span>
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">

          {/* ══ SLIP ══════════════════════════════════════════════ */}
          {method === "slip" && (
            <motion.div
              key="slip"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              className="space-y-5"
            >
              <div className="rounded-2xl border border-border bg-card p-6 space-y-5">

                {/* Title */}
                <div className="flex items-center gap-3 pb-4 border-b border-border">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center">
                    <Upload className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h2 className="font-bold text-foreground">แนบสลิปการโอนเงิน</h2>
                    <p className="text-xs text-muted-foreground">
                      ระบบอ่านยอดเงินจาก QR Code อัตโนมัติ — เงินเข้าตามยอดจริง ไม่ต้องรอแอดมิน
                    </p>
                  </div>
                </div>

                {/* Bank info */}
                <div className="rounded-xl bg-muted/30 border border-border p-4 space-y-2 text-sm">
                  <p className="font-semibold text-foreground">บัญชีรับโอนเงิน</p>
                  {bankList.map((b, i) => (
                    <div key={i} className="text-muted-foreground">
                      <span className="text-foreground font-medium">{b.bank_name}</span>
                      <br />
                      เลขบัญชี:{" "}
                      <span className="text-primary font-mono font-bold">{b.account_number}</span>
                      {b.account_name && <> — {b.account_name}</>}
                    </div>
                  ))}
                </div>

                {/* Slip upload */}
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    แนบสลิปการโอนเงิน <span className="text-red-400">*</span>
                  </label>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleSlipFileChange}
                  />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="w-full h-44 rounded-xl border-2 border-dashed border-border hover:border-primary/50 flex flex-col items-center justify-center gap-2 transition-colors overflow-hidden"
                  >
                    {slipPreview ? (
                      <img src={slipPreview} alt="slip" className="h-full w-full object-contain" />
                    ) : (
                      <>
                        <QrCode className="w-9 h-9 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">คลิกเพื่ออัพโหลดสลิป</span>
                        <span className="text-xs text-muted-foreground/60">
                          PNG · JPG · JPEG — ถ่ายให้เห็น QR Code ชัดๆ
                        </span>
                      </>
                    )}
                  </button>
                  {slipPreview && (
                    <button
                      onClick={clearSlip}
                      className="mt-2 text-xs text-red-400 hover:text-red-300 transition-colors"
                    >
                      ลบรูปภาพ
                    </button>
                  )}
                </div>

                {/* QR hint */}
                {slipPreview && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="rounded-xl bg-blue-500/8 border border-blue-500/20 p-3 flex gap-2"
                  >
                    <QrCode className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-blue-300/80">
                      ระบบจะอ่านยอดเงิน บัญชีผู้รับ และเลขอ้างอิงจาก QR Code โดยอัตโนมัติ
                      — ไม่ต้องกรอกยอดเอง
                    </p>
                  </motion.div>
                )}

                <Button
                  onClick={submitSlip}
                  disabled={slipSubmitting || !slipPreview}
                  className="w-full h-12 font-semibold gap-2"
                >
                  {slipSubmitting ? (
                    <>
                      <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      กำลังอ่าน QR และตรวจสอบ...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      ตรวจสอบสลิปอัตโนมัติ
                    </>
                  )}
                </Button>
              </div>

              {/* Info strip */}
              <div className="rounded-xl bg-green-500/5 border border-green-500/20 p-4 flex gap-3">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs text-green-300/80">
                    ระบบอ่าน QR Code จากสลิปโดยตรง เงินเข้าตามยอดที่โอนจริง ไม่ต้องรอแอดมิน
                  </p>
                  <p className="text-xs text-green-400/50">
                    เพื่อความแม่นยำ: ถ่ายให้เห็น QR Code ชัดๆ แสงสว่างพอ ไม่เบลอ ครบทั้งสลิป
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* ══ ANGPAO ════════════════════════════════════════════ */}
          {method === "angpao" && (
            <motion.div
              key="angpao"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              className="space-y-5"
            >
              <div className="rounded-2xl border border-border bg-card p-6 space-y-5">
                <div className="flex items-center gap-3 pb-4 border-b border-border">
                  <div className="w-10 h-10 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center">
                    <Gift className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <h2 className="font-bold text-foreground">ซองของขวัญอั่งเปา</h2>
                    <p className="text-xs text-muted-foreground">
                      TrueMoney Gift — วางลิ้งค์แล้วเงินเด้งเข้าทันที ไม่ต้องรอแอดมิน
                    </p>
                  </div>
                </div>

                <div className="rounded-xl bg-muted/30 border border-border p-4 text-sm">
                  <p className="font-semibold text-foreground mb-1">เบอร์รับอั่งเปา TrueMoney</p>
                  <p className="text-2xl font-bold text-primary font-mono">{walletPhone}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    ส่งซองอั่งเปาไปที่เบอร์นี้ แล้วนำ URL ที่ได้มาวางด้านล่าง
                  </p>
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    URL ซองอั่งเปา <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="url"
                    value={angpaoUrl}
                    onChange={e => setAngpaoUrl(e.target.value)}
                    placeholder="https://gift.truemoney.com/campaign/?v=..."
                    className="w-full px-4 py-3 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 text-sm font-mono"
                  />
                </div>

                <Button onClick={submitAngpao} disabled={angpaoSubmitting} className="w-full h-12 font-semibold gap-2">
                  {angpaoSubmitting
                    ? <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    : <><Gift className="w-4 h-4" /> รับอั้งเปาอัตโนมัติ</>}
                </Button>
              </div>

              <div className="rounded-xl bg-green-500/5 border border-green-500/20 p-4 flex gap-3">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-green-300/80">
                  ระบบรับอั้งเปาอัตโนมัติ เงินเข้าวอเล็ทของคุณทันทีหลังกด ไม่ต้องรอแอดมิน
                </p>
              </div>
            </motion.div>
          )}

          {/* ══ REDEEM ════════════════════════════════════════════ */}
          {method === "redeem" && (
            <motion.div
              key="redeem"
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
              className="space-y-5"
            >
              <div className="rounded-2xl border border-border bg-card p-6 space-y-5">
                <div className="flex items-center gap-3 pb-4 border-b border-border">
                  <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
                    <Link2 className="w-5 h-5 text-violet-400" />
                  </div>
                  <div>
                    <h2 className="font-bold text-foreground">กิฟโค้ดจากเว็บไซต์</h2>
                    <p className="text-xs text-muted-foreground">Redeem Code — เพิ่มเงินทันทีเมื่อโค้ดถูกต้อง</p>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    โค้ดเติมเงิน <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={redeemCode}
                    onChange={e => setRedeemCode(e.target.value.toUpperCase())}
                    placeholder="เช่น WELCOME100"
                    className="w-full px-4 py-3 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 text-sm font-mono tracking-widest uppercase"
                    onKeyDown={e => { if (e.key === "Enter") submitRedeem(); }}
                  />
                </div>

                <Button onClick={submitRedeem} disabled={redeemSubmitting} className="w-full h-12 font-semibold gap-2">
                  <CheckCircle className="w-4 h-4" /> ใช้โค้ดเติมเงิน
                </Button>
              </div>

              <div className="rounded-xl bg-green-500/5 border border-green-500/20 p-4 flex gap-3">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-green-300/80">
                  เมื่อโค้ดถูกต้อง เงินจะถูกเพิ่มเข้าบัญชีทันที ไม่ต้องรอแอดมิน
                </p>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {/* Confirm dialogs */}
      <ConfirmDialog
        open={slipConfirmOpen}
        title="ยืนยันการตรวจสอบสลิป"
        body="ระบบจะอ่าน QR Code จากสลิปและเติมเงินตามยอดที่โอนมาจริง"
        onConfirm={confirmSlip}
        onCancel={() => setSlipConfirmOpen(false)}
        loading={slipSubmitting}
      />
      <ConfirmDialog
        open={angpaoConfirmOpen}
        title="ยืนยันการรับอั้งเปา"
        body="ระบบจะรับอั้งเปาและเพิ่มเงินเข้าวอเล็ทของคุณทันที"
        onConfirm={confirmAngpao}
        onCancel={() => setAngpaoConfirmOpen(false)}
        loading={angpaoSubmitting}
      />
      <ConfirmDialog
        open={redeemConfirmOpen}
        title="ยืนยันการใช้โค้ด"
        body={`โค้ด: ${redeemCode} — เงินจะถูกเพิ่มเข้าบัญชีทันที`}
        onConfirm={confirmRedeem}
        onCancel={() => setRedeemConfirmOpen(false)}
        loading={redeemSubmitting}
      />
    </>
  );
}
