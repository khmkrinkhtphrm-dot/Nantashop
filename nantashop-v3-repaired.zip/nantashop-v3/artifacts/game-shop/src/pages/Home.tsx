import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Eye, Package, ShoppingBag, ChevronLeft, ChevronRight, Search, X } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { api } from "@/lib/api";

import { Product, Category, Slider, Order, QuickLink } from "@/types";
import {
  mockSliders, mockQuickLinks,
  mockStats, mockAllOrders
} from "@/lib/mock-data";
import ProductCard from "@/components/ProductCard";

/* ── helpers ── */
function formatThaiDate(iso: string) {
  const d = new Date(iso);
  const months = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
  const buddhistYear = d.getFullYear() - 1900 + 43;
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${d.getDate()} ${months[d.getMonth()]} ${buddhistYear} – ${h}:${m} น.`;
}

/* ══════════════════════════════════════════════════
   STAT CARD
══════════════════════════════════════════════════ */
function StatCard({
  label, sublabel, value, icon
}: { label: string; sublabel: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="relative rounded-2xl border border-border bg-card overflow-hidden p-4">
      <p className="text-xs text-foreground/70 mb-1">{label}</p>
      <p className="text-3xl font-extrabold neon-text leading-tight mb-0.5">{value}</p>
      <p className="text-[11px] text-muted-foreground">{sublabel}</p>
      <div className="absolute right-1 bottom-0 opacity-[0.07] text-primary pointer-events-none select-none">
        {icon}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════
   QUICK LINK BUTTON
══════════════════════════════════════════════════ */
function QuickLinkBtn({ title, imageUrl, onClick }: { title: string; imageUrl: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="relative rounded-2xl overflow-hidden aspect-[2/1] w-full border border-border hover:border-primary/40 transition-all group"
    >
      <img src={imageUrl} alt={title} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
      <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity" />
      {/* bottom bar */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between px-3 py-1.5">
        <span className="text-[9px] text-white/60 font-medium">Nantashop</span>
        <span className="text-[9px] text-primary font-bold tracking-wide">▶ CLICK NOW!</span>
      </div>
      {/* title */}
      <div className="absolute inset-0 flex items-center justify-end pr-4">
        <span className="text-white font-extrabold text-lg leading-tight drop-shadow-lg text-right" style={{ fontFamily: "'Orbitron', sans-serif" }}>
          {title}
        </span>
      </div>
    </button>
  );
}

/* ══════════════════════════════════════════════════
   MAIN HOME PAGE
══════════════════════════════════════════════════ */
export default function Home() {
  const { cmsConfig, currentUser } = useApp();
  const [, setLocation] = useLocation();

  const [sliders, setSliders] = useState<Slider[]>(mockSliders);
  const [sliderIdx, setSliderIdx] = useState(0);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [recentOrders, setRecentOrders] = useState<Order[]>(mockAllOrders);
  const [search, setSearch] = useState("");
  const [stats] = useState(mockStats);
  const [popupOpen, setPopupOpen] = useState(false);
  const [noShowChecked, setNoShowChecked] = useState(false);
  const recentRef = useRef<HTMLDivElement>(null);
  const [recentPage, setRecentPage] = useState(0);

  /* Load from API */
  useEffect(() => {
    api.get("/sliders").then((d: Slider[]) => { if (d?.length) setSliders(d); }).catch(() => {});
    api.get("/categories").then((d: Category[]) => { if (Array.isArray(d)) setCategories(d); }).catch(() => {});
    api.get("/products").then((d: Product[]) => { if (Array.isArray(d)) setProducts(d); }).catch(() => {});
    api.get("/orders").then((d: Order[]) => { if (d?.length) setRecentOrders(d); }).catch(() => {});
  }, []);

  /* Popup — with 1-hour localStorage suppression */
  useEffect(() => {
    if (!cmsConfig.enable_popup) return;
    const stored = localStorage.getItem("popup_hide_until");
    if (stored && Date.now() < parseInt(stored)) return; // still suppressed
    const t = setTimeout(() => setPopupOpen(true), 800);
    return () => clearTimeout(t);
  }, [cmsConfig.enable_popup]);

  function closePopup() {
    if (noShowChecked) {
      localStorage.setItem("popup_hide_until", String(Date.now() + 60 * 60 * 1000));
    }
    setPopupOpen(false);
  }

  /* Auto-slide */
  useEffect(() => {
    if (!sliders.length) return;
    const t = setInterval(() => setSliderIdx(i => (i + 1) % sliders.length), 5000);
    return () => clearInterval(t);
  }, [sliders.length]);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    (p.description || "").toLowerCase().includes(search.toLowerCase())
  );

  const [quickLinks, setQuickLinks] = useState(mockQuickLinks);
  useEffect(() => {
    api.get("/quick-links").then((d: typeof mockQuickLinks) => { if (d?.length) setQuickLinks(d); }).catch(() => {});
  }, []);

  const RECENT_VISIBLE = 2;
  const recentMaxPage = Math.max(0, recentOrders.length - RECENT_VISIBLE);

  return (
    <div className="min-h-screen bg-background pb-20">

      {/* ── Popup (matches reference: product image + ปิดหน้าต่าง + checkbox) ── */}
      <AnimatePresence>
        {cmsConfig.enable_popup && popupOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.88, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.88, opacity: 0 }}
              transition={{ type: "spring", damping: 22, stiffness: 260 }}
              className="relative bg-card border border-border rounded-2xl max-w-sm w-full shadow-2xl shadow-black/80 overflow-hidden"
            >
              {/* Main promo image */}
              <div className="w-full bg-secondary" style={{ aspectRatio: "1/1" }}>
                <img
                  src={cmsConfig.popup_image_url || products[0]?.image_url || "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&q=80"}
                  alt="promotion"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Bottom action row */}
              <div className="px-4 py-3 flex items-center justify-between gap-3 bg-card">
                <button
                  onClick={closePopup}
                  className="px-5 py-2.5 rounded-full text-white font-bold text-sm flex-shrink-0"
                  style={{ background: "linear-gradient(135deg,#0ea5e9,#0369a1)" }}
                >
                  ปิดหน้าต่าง
                </button>
                <label className="flex items-center gap-2 cursor-pointer text-muted-foreground text-xs select-none">
                  <input
                    type="checkbox"
                    checked={noShowChecked}
                    onChange={e => setNoShowChecked(e.target.checked)}
                    className="w-4 h-4 rounded accent-primary"
                  />
                  ไม่แสดงอีก 1 ชม.
                </label>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ════════════════════
          SECTION 1: HERO SLIDER
      ════════════════════ */}
      {sliders.length > 0 && (
        <div className="px-3 pt-3">
          <div className="relative rounded-2xl overflow-hidden w-full aspect-[2.4/1] bg-secondary">
            <AnimatePresence mode="wait">
              <motion.div
                key={sliders[sliderIdx].id}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.45 }}
                className="absolute inset-0"
              >
                <img
                  src={sliders[sliderIdx].image_url}
                  alt={sliders[sliderIdx].title}
                  className="w-full h-full object-cover cursor-pointer"
                  onClick={() => sliders[sliderIdx].link_url && setLocation(sliders[sliderIdx].link_url!)}
                />
                {/* overlay text */}
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-transparent" />
                {sliders[sliderIdx].title && (
                  <div className="absolute bottom-3 left-3 right-3">
                    <p className="text-white text-sm font-bold drop-shadow-lg line-clamp-2">{sliders[sliderIdx].title}</p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
            {/* dots */}
            {sliders.length > 1 && (
              <div className="absolute bottom-2 right-3 flex gap-1">
                {sliders.map((_, i) => (
                  <button key={i} onClick={() => setSliderIdx(i)} className={`h-1.5 rounded-full transition-all ${i === sliderIdx ? "w-5 bg-primary" : "w-1.5 bg-white/30"}`} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ════════════════════
          SECTION 2: STATS
      ════════════════════ */}
      <div className="px-3 pt-3 grid grid-cols-2 gap-2.5">
        <StatCard
          label="สมาชิกทั้งหมด"
          sublabel="Users Registered"
          value={stats.total_users.toLocaleString()}
          icon={<Users size={100} />}
        />
        <StatCard
          label="เข้าชมเว็บไซต์"
          sublabel="Total Visits"
          value={stats.total_visits.toLocaleString()}
          icon={<Eye size={100} />}
        />
        <StatCard
          label="พร้อมจำหน่าย"
          sublabel="Ready Stock"
          value={stats.ready_stock.toLocaleString()}
          icon={<Package size={100} />}
        />
        <StatCard
          label="ยอดขายสินค้า"
          sublabel="Total Sales"
          value={stats.total_sales.toLocaleString()}
          icon={<ShoppingBag size={100} />}
        />
      </div>

      {/* ════════════════════
          SECTION 3: QUICK LINKS
      ════════════════════ */}
      <div className="px-3 pt-4 grid grid-cols-2 gap-2.5">
        {quickLinks.map(ql => (
          <QuickLinkBtn
            key={ql.id}
            title={ql.title}
            imageUrl={(ql as QuickLink & { image_url?: string }).image_url || ""}
            onClick={() => setLocation(ql.target_page)}
          />
        ))}
      </div>

      {/* ════════════════════
          SECTION 4: CATEGORIES
      ════════════════════ */}
      <div className="px-3 pt-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-lg">⊞</span>
          <h2 className="text-base font-bold text-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>หมวดหมู่</h2>
        </div>
        <div className="space-y-2.5">
          {categories.filter(c => c.is_featured).map(cat => {
            const catProducts = products.filter(p => p.category_id === cat.id);
            return (
              <button
                key={cat.id}
                onClick={() => setLocation("/products")}
                className="w-full rounded-2xl border border-border bg-card overflow-hidden text-left"
              >
                {cat.image_url && (
                  <img src={cat.image_url} alt={cat.name} className="w-full h-24 object-cover" />
                )}
                <div className="flex items-center justify-between px-3 py-2.5">
                  <p className="text-sm font-semibold text-foreground">{cat.name}</p>
                  <p className="text-xs text-muted-foreground">{catProducts.length} สินค้า</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ════════════════════
          SECTION 5: PRODUCTS
      ════════════════════ */}
      <div className="px-3 pt-5">
        <div className="flex items-start gap-2 mb-3">
          <span className="text-lg">🛒</span>
          <div>
            <h2 className="text-base font-bold text-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>สินค้าแนะนำ</h2>
            <p className="text-[11px] text-muted-foreground">Recommended Products</p>
          </div>
        </div>

        {/* divider */}
        <div className="border-t border-border mb-4" />

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="ค้นหาสินค้า..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-card border border-border text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
          />
          {search && (
            <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2">
              <X className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          )}
        </div>

        {/* Product grid — clicking navigates to /products/:id detail page */}
        {filteredProducts.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground text-sm">ไม่พบสินค้า</div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {filteredProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>

      {/* ════════════════════
          SECTION 6: RECENT PURCHASES
      ════════════════════ */}
      {recentOrders.length > 0 && (
        <div className="px-3 pt-6">
          <div className="flex items-center justify-between mb-1">
            <div>
              <h2 className="text-base font-bold neon-text" style={{ fontFamily: "'Orbitron', sans-serif" }}>การสั่งซื้อล่าสุด</h2>
              <p className="text-[11px] text-muted-foreground mt-0.5">Real-time Purchase History</p>
            </div>
            <div className="flex gap-1.5">
              <button
                onClick={() => setRecentPage(p => Math.max(0, p - 1))}
                className="w-8 h-8 rounded-full border border-border bg-card flex items-center justify-center hover:border-primary/50 transition-colors disabled:opacity-40"
                disabled={recentPage === 0}
              >
                <ChevronLeft className="w-4 h-4 text-foreground" />
              </button>
              <button
                onClick={() => setRecentPage(p => Math.min(recentMaxPage, p + 1))}
                className="w-8 h-8 rounded-full border border-border bg-card flex items-center justify-center hover:border-primary/50 transition-colors disabled:opacity-40"
                disabled={recentPage >= recentMaxPage}
              >
                <ChevronRight className="w-4 h-4 text-foreground" />
              </button>
            </div>
          </div>

          {/* divider */}
          <div className="border-t border-border my-3" />

          <div ref={recentRef} className="grid grid-cols-2 gap-2.5 overflow-hidden">
            {recentOrders.slice(recentPage, recentPage + RECENT_VISIBLE).map(order => {
              const prod = products.find(p => p.id === order.product_id);
              return (
                <div key={order.id} className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="aspect-square bg-secondary overflow-hidden">
                    <img
                      src={prod?.image_url || "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&q=80"}
                      alt={order.product_name}
                      className="w-full h-full object-cover"
                      onError={(e) => { (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&q=80"; }}
                    />
                  </div>
                  <div className="p-2.5">
                    <p className="text-[12px] font-semibold text-foreground line-clamp-2 leading-snug mb-1">{order.product_name}</p>
                    <p className="text-[11px] text-muted-foreground">โดย: Admin</p>
                    <p className="text-[11px] text-orange-400 font-medium mt-0.5">{formatThaiDate(order.created_at)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ════════════════════
          ANNOUNCEMENT BANNER
      ════════════════════ */}
      {cmsConfig.announcement && (
        <div className="mx-3 mt-5 rounded-xl border border-primary/30 bg-primary/10 px-4 py-3">
          <p className="text-xs text-primary font-medium text-center">{cmsConfig.announcement}</p>
        </div>
      )}
    </div>
  );
}
