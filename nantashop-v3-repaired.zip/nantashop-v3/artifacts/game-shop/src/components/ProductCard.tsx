import { Flame, ShoppingCart } from "lucide-react";
import { motion } from "framer-motion";
import { Product } from "@/types";
import { useLocation } from "wouter";

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  const [, setLocation] = useLocation();

  const discount = product.show_fake_price && product.fake_price
    ? Math.round((1 - product.real_price / product.fake_price) * 100)
    : null;

  const imgSrc = product.image_url || "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&q=80";
  const outOfStock = (product.stock ?? 0) === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="group relative rounded-xl border border-border bg-card overflow-hidden hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10 transition-all duration-300"
      data-testid={`card-product-${product.id}`}
    >
      {/* Image */}
      <div
        className="relative h-44 overflow-hidden bg-secondary cursor-pointer"
        onClick={() => setLocation(`/products/${product.id}`)}
      >
        <img
          src={imgSrc}
          alt={product.name}
          className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ${outOfStock ? "opacity-50 grayscale" : ""}`}
          onError={(e) => { (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&q=80"; }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />

        {/* Badges top-left */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.hot_badge && (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/90 text-white text-xs font-bold shadow">
              <Flame className="w-3 h-3" /> ขายดี
            </span>
          )}
          {discount && !outOfStock && (
            <span className="px-2 py-0.5 rounded-full bg-green-500/90 text-white text-xs font-bold shadow">
              -{discount}%
            </span>
          )}
        </div>

        {/* Out of stock overlay */}
        {outOfStock && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="px-4 py-2 rounded-lg border-2 border-red-500/70 bg-black/60">
              <p className="text-red-400 font-bold text-sm">สินค้าหมด</p>
            </div>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <h3
          className="font-semibold text-foreground text-sm leading-tight mb-3 line-clamp-2 cursor-pointer hover:text-primary transition-colors"
          onClick={() => setLocation(`/products/${product.id}`)}
          data-testid={`text-product-name-${product.id}`}
        >
          {product.name}
        </h3>

        <div className="flex items-end justify-between mb-3">
          <div>
            {product.show_fake_price && product.fake_price && (
              <p className="text-xs text-muted-foreground line-through">
                ฿{product.fake_price.toLocaleString()}
              </p>
            )}
            <p className="text-xl font-bold text-primary" data-testid={`text-price-${product.id}`}>
              ฿{product.real_price.toLocaleString()}
            </p>
          </div>
          <p className={`text-xs font-medium ${outOfStock ? "text-red-400" : "text-green-400"}`}>
            มี {product.stock ?? 0} ชิ้น
          </p>
        </div>

        {outOfStock ? (
          <button
            disabled
            className="w-full py-2.5 rounded-xl text-sm font-semibold bg-secondary text-muted-foreground border border-border cursor-not-allowed opacity-70"
          >
            สินค้าหมด
          </button>
        ) : (
          <button
            onClick={() => setLocation(`/products/${product.id}`)}
            className="w-full py-2.5 rounded-xl text-sm font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 shadow shadow-primary/20"
          >
            <ShoppingCart className="w-4 h-4" />
            ซื้อสินค้า
          </button>
        )}
      </div>
    </motion.div>
  );
}
