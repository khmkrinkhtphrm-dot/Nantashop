import { useState } from "react";
import { useLocation } from "wouter";
import {
  Home, ShoppingCart, Wallet, Gamepad2, Package,
  Search, Settings, History, ShieldCheck, X, LogOut,
  ChevronDown, User
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useApp } from "@/context/AppContext";

export default function Navbar() {
  const { currentUser, cmsConfig, logout } = useApp();
  const [, setLocation] = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [profileDropOpen, setProfileDropOpen] = useState(false);

  function go(path: string) {
    setLocation(path);
    setDrawerOpen(false);
    setProfileDropOpen(false);
  }

  const initials = currentUser?.username?.slice(0, 2).toUpperCase() ?? "NS";

  const navItems = [
    { icon: Home, label: "หน้าหลัก", path: "/" },
    { icon: ShoppingCart, label: "ร้านค้า", path: "/products" },
    { icon: Wallet, label: "เติมเงิน", path: "/topup" },
    { icon: Gamepad2, label: "มินิเกม", path: "/minigame" },
    { icon: Package, label: "ออเดอร์", path: "/profile" },
    { icon: Search, label: "ค้นหาชื่อสินค้า", path: "/products" },
  ];
  const accountItems = [
    { icon: Settings, label: "ตั้งค่าบัญชี", path: "/profile" },
    { icon: History, label: "ประวัติการสั่งซื้อ", path: "/profile" },
  ];

  return (
    <>
      {/* ── TOP NAVBAR ─────────────────────────────────── */}
      <nav className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-md">
        <div className="px-3 h-14 flex items-center justify-between max-w-2xl mx-auto gap-2">

          {/* LEFT: Logo + shop name */}
          <button onClick={() => go("/")} className="flex items-center gap-2 flex-shrink-0">
            {cmsConfig.logo_url ? (
              <img
                src={cmsConfig.logo_url}
                alt={cmsConfig.site_name}
                className="h-9 w-9 rounded-lg object-contain"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
            ) : (
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "linear-gradient(135deg,#0ea5e9,#0369a1)" }}>
                <Gamepad2 className="w-5 h-5 text-white" />
              </div>
            )}
            <span className="text-sm font-extrabold text-foreground leading-none" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              {cmsConfig.site_name}
            </span>
          </button>

          {/* RIGHT: Profile / Login + Hamburger */}
          <div className="flex items-center gap-2 ml-auto">
            {currentUser ? (
              /* Profile dropdown button */
              <div className="relative">
                <button
                  onClick={() => setProfileDropOpen(o => !o)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-secondary border border-border hover:border-primary/50 transition-all"
                >
                  {/* avatar */}
                  <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center overflow-hidden flex-shrink-0">
                    {currentUser.avatar_url ? (
                      <img src={currentUser.avatar_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-[11px] font-bold text-primary">{initials}</span>
                    )}
                  </div>
                  {/* balance */}
                  <span className="text-xs font-bold neon-text hidden xs:inline">
                    🪙 {currentUser.balance.toLocaleString("th-TH", { minimumFractionDigits: 2 })}
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform flex-shrink-0 ${profileDropOpen ? "rotate-180" : ""}`} />
                </button>

                <AnimatePresence>
                  {profileDropOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setProfileDropOpen(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-52 rounded-2xl border border-border bg-card shadow-2xl shadow-black/60 overflow-hidden z-50"
                      >
                        {/* User info */}
                        <div className="px-4 py-3 border-b border-border bg-secondary/50">
                          <p className="text-sm font-bold text-foreground">{currentUser.username}</p>
                          <p className="text-xs neon-text font-semibold">🪙 {currentUser.balance.toLocaleString("th-TH", { minimumFractionDigits: 2 })}</p>
                        </div>
                        <div className="py-1">
                          <button onClick={() => go("/profile")} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-foreground hover:bg-secondary transition-colors">
                            <Settings className="w-4 h-4 text-muted-foreground" />ตั้งค่าบัญชี
                          </button>
                          <button onClick={() => go("/profile")} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-foreground hover:bg-secondary transition-colors">
                            <History className="w-4 h-4 text-muted-foreground" />ประวัติการสั่งซื้อ
                          </button>
                          <button onClick={() => go("/profile")} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-foreground hover:bg-secondary transition-colors">
                            <Wallet className="w-4 h-4 text-muted-foreground" />ประวัติการเติมเงิน
                          </button>
                          {currentUser.is_admin && (
                            <button onClick={() => go("/admin")} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 transition-colors">
                              <ShieldCheck className="w-4 h-4" />หลังบ้าน (Admin Panel)
                            </button>
                          )}
                          <div className="border-t border-border my-1" />
                          <button onClick={() => { logout(); setProfileDropOpen(false); }} className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/10 transition-colors">
                            <LogOut className="w-4 h-4" />ออกจากระบบ
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                onClick={() => go("/auth")}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-bold"
              >
                <User className="w-3.5 h-3.5" />เข้าสู่ระบบ
              </button>
            )}

            {/* Hamburger */}
            <button
              onClick={() => setDrawerOpen(true)}
              aria-label="เมนู"
              className="p-2.5 rounded-xl hover:bg-secondary transition-colors flex-shrink-0"
            >
              <div className="flex flex-col gap-1.5">
                <span className="block w-5 h-0.5 bg-foreground/80 rounded-full" />
                <span className="block w-5 h-0.5 bg-foreground/80 rounded-full" />
                <span className="block w-5 h-0.5 bg-foreground/80 rounded-full" />
              </div>
            </button>
          </div>
        </div>
      </nav>

      {/* ── DRAWER ─────────────────────────────────────── */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm"
              onClick={() => setDrawerOpen(false)}
            />
            <motion.div
              initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed left-0 top-0 h-full w-72 z-[70] bg-card border-r border-border flex flex-col overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-4 py-4 border-b border-border">
                <span className="text-base font-bold text-foreground" style={{ fontFamily: "'Orbitron', sans-serif" }}>เมนูหลัก</span>
                <button onClick={() => setDrawerOpen(false)} className="p-1.5 rounded-lg hover:bg-secondary">
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>

              {/* User card */}
              {currentUser ? (
                <div className="mx-3 mt-4 mb-2 rounded-xl bg-secondary border border-border p-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {currentUser.avatar_url ? (
                      <img src={currentUser.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <span className="text-sm font-bold text-primary">{initials}</span>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-foreground">{currentUser.username}</p>
                    <p className="text-xs neon-text font-semibold">🪙 {currentUser.balance.toLocaleString("th-TH", { minimumFractionDigits: 2 })}</p>
                  </div>
                </div>
              ) : (
                <div className="mx-3 mt-4 mb-2">
                  <button onClick={() => go("/auth")} className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold">
                    เข้าสู่ระบบ / สมัครสมาชิก
                  </button>
                </div>
              )}

              {/* Navigation */}
              <div className="px-3 pt-4">
                <p className="text-[10px] text-muted-foreground font-semibold uppercase tracking-widest mb-2 px-2">Navigation</p>
                <div className="space-y-0.5">
                  {navItems.map(({ icon: Icon, label, path }) => (
                    <button key={label} onClick={() => go(path)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-foreground hover:bg-secondary hover:text-primary transition-all group">
                      <Icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                      <span>{label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Account */}
              <div className="px-3 pt-4">
                <p className="text-[10px] text-muted-foreground font-semibold uppercase tracking-widest mb-2 px-2">Account</p>
                <div className="space-y-0.5">
                  {accountItems.map(({ icon: Icon, label, path }) => (
                    <button key={label} onClick={() => go(path)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-foreground hover:bg-secondary hover:text-primary transition-all group">
                      <Icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                      <span>{label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Admin + logout */}
              <div className="px-3 pt-3 pb-6 mt-auto">
                {currentUser?.is_admin && (
                  <button onClick={() => go("/admin")}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-red-400 hover:bg-red-500/10 transition-all">
                    <ShieldCheck className="w-4 h-4 flex-shrink-0" />ระบบหลังบ้าน
                  </button>
                )}
                {currentUser && (
                  <button onClick={() => { logout(); setDrawerOpen(false); }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-muted-foreground hover:text-destructive hover:bg-secondary transition-all">
                    <LogOut className="w-4 h-4 flex-shrink-0" />ออกจากระบบ
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
