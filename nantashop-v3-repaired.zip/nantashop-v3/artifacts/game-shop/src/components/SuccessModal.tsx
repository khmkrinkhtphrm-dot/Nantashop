import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";

interface SuccessModalProps {
  open: boolean;
  message?: string;
  onClose: () => void;
}

export default function SuccessModal({ open, message = "บันทึกสำเร็จ", onClose }: SuccessModalProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-6"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            onClick={e => e.stopPropagation()}
            className="bg-white rounded-3xl shadow-2xl p-8 flex flex-col items-center max-w-xs w-full"
          >
            {/* Animated checkmark circle */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.1, type: "spring", damping: 15 }}
              className="w-20 h-20 rounded-full border-4 border-primary flex items-center justify-center mb-6"
              style={{ borderColor: "#0ea5e9" }}
            >
              <motion.div
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ delay: 0.25, duration: 0.4 }}
              >
                <Check className="w-10 h-10" style={{ color: "#0ea5e9" }} strokeWidth={3} />
              </motion.div>
            </motion.div>

            <h2 className="text-2xl font-extrabold text-gray-800 mb-2" style={{ fontFamily: "Sarabun, sans-serif" }}>สำเร็จ</h2>
            <p className="text-gray-500 text-sm text-center mb-6" style={{ fontFamily: "Sarabun, sans-serif" }}>{message}</p>

            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl text-white font-bold text-base transition-all active:scale-95"
              style={{ background: "linear-gradient(135deg, #0ea5e9, #0284c7)", fontFamily: "Sarabun, sans-serif" }}
            >
              ตกลง
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
